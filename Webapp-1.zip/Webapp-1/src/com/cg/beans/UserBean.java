package com.cg.beans;

public class UserBean {
private String emailid,password,name;

public String getEmailid() {
	return emailid;
}

public void setEmailid(String emailid) {
	this.emailid = emailid;
}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public UserBean(String emailid, String password) {
	super();
	this.emailid = emailid;
	this.password = password;
}

public UserBean() {
}

public UserBean(String emailid, String password, String name) {
	super();
	this.emailid = emailid;
	this.password = password;
	this.name = name;
}

}
