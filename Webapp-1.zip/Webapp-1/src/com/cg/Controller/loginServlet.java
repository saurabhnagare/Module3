package com.cg.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.beans.UserBean;

/**
 * Servlet implementation class loginServlet
 */
@WebServlet("/login")
public class loginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public loginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
/*	PrintWriter out = response.getWriter();
	String emailid = request.getParameter("emailid");
	String password = request.getParameter("password");
	
	out.print("<html><body><div>");
	
	if(emailid.equals("saurabhrnagare@gmail.com")&&password.equals("abc12345"))
		out.println("<font color='olive' size=10>Welcome "+emailid);
	else
		out.println("<font color='red' size=10>Username or password is wrong ");
	
	
	out.print("</font></div></body></html>");
	
	
	*/
		
		
		String associateId = request.getParameter("associateId");
		String password = request.getParameter("password");
		UserBean user = new UserBean(associateId, password);
		RequestDispatcher dispatcher=null;
		
		if(user.getName().equals("Saurabh")&&user.getPassword().equals("abc12345")) {
				dispatcher = request.getRequestDispatcher("loginSuccesPage.jsp");
				request.setAttribute("user", user);
				dispatcher.forward(request, response);
		}
		else {
			dispatcher = request.getRequestDispatcher("loginErroPage.jsp");
			request.setAttribute("errorMessage", "Username or password is Wrong");
			dispatcher.forward(request, response);
			
		}
		
	}

}
