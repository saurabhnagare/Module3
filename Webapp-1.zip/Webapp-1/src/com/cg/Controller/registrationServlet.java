package com.cg.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class registrationServlet
 */
@WebServlet("/registration")
public class registrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public registrationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		PrintWriter out = response.getWriter();
		String name = request.getParameter("name");
		String emailid = request.getParameter("emailid");
		String password = request.getParameter("password");
		String mob = request.getParameter("mob");
		String gender = request.getParameter("gender");
		String stream = request.getParameter("stream");
		String vehicle = request.getParameter("vehicle");
		String message = request.getParameter("message");
		
		out.print("<html><body><div>");
		
		out.println("Your entered details:");
		out.println("<font color='olive' size=10>Name: "+name);
		out.println("<font color='olive' size=10>Emailid: "+emailid);
		out.println("<font color='olive' size=10>Mobile no: "+mob);
		out.println("<font color='olive' size=10>Gender: "+gender);
		out.println("<font color='olive' size=10>Stream: "+stream);
		out.println("<font color='olive' size=10>Vehicle: "+vehicle);
		out.println("<font color='olive' size=10>Comments: "+message);
		
		
	/*	
		if(emailid.equals("saurabhrnagare@gmail.com")&&password.equals("abc12345"))
			out.println("<font color='olive' size=10>Welcome "+emailid);
		else
			out.println("<font color='red' size=10>Username or password is wrong ");
		
		*/
		out.print("</font></div></body></html>");
		
	
	
	
	
	
	}

}
